// YOU CAN SET HERE YOUR IP TO TEST IN YOUR LAN (e.g. server on PC, client on your mobile phone)
export const BASE_API = "http://127.0.0.1:3000/api"