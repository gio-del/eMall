import MapLeaflet from '../component/Map/MapLeaflet.jsx'

export default function MapView() {
  return <MapLeaflet />
}
