# Using Docker
Build the container:
```cmd
docker-compose build
```
Start the container:
```cmd
docker-compose up
```